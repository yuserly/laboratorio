import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

const routes = [
    {
        path: "/",
        name: "home",
        component: () => import("./views/pages/dashboard/index.vue")
    },
    {
        path: "/generar-qr",
        name: "generar qr",
        component: () => import("./views/pages/generarqr/index.vue")
    }
];

const router = new VueRouter({
    routes,
    // Use the HTML5 history API (i.e. normal-looking routes)
    // instead of routes with hashes (e.g. example.com/#/about).
    // This may require some server configuration in production:
    // https://router.vuejs.org/en/essentials/history-mode.html#example-server-configurations
    mode: "history",
    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition;
        } else {
            return {
                x: 0,
                y: 0
            };
        }
    }
});

router.beforeEach((to, from, next) => {
    //A Logged-in user can't go to login page again
    if (to.name === "login" && localStorage.getItem("token")) {
        //   let rol = atob(localStorage.getItem('cm9s'));

        router.push({
            name: "home"
        });

        //the route requires authentication
    } else if (to.matched.some(record => record.meta.requiresAuth)) {
        if (!localStorage.getItem("token")) {
            //user not logged in, send them to login page
            router.push({
                name: "login",
                query: {
                    to: to.name
                }
            });
        } else {
            if (!hasAccess(to.name)) {
                //   let rol = atob(localStorage.getItem('cm9s'));

                router.push({
                    name: "home"
                });
            }
        }
    }

    return next();
});

function hasAccess(name) {
    // const rol = atob(localStorage.getItem('cm9s'));

    switch (name) {
        case "home":
            return true;

        case "generar qr":
            return true;

        default:
            return false;
    }
}

export default router;
