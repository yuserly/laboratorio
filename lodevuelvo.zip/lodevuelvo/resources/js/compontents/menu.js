export const menuItems = [
    {
        id: 1,
        label: "Administración",
        isTitle: true
    },
    {
        id: 2,
        label: "Generar QR",
        icon: "uil-dialpad",
        link: "/generar-qr"
    },
    {
        id: 3,
        label: "Colegios",
        icon: "uil-building",
        link: "/"
    },
    {
        id: 4,
        label: "Usuarios Colegios",
        icon: "uil-user-plus",
        link: "/"
    },
    {
        id: 5,
        label: "Ventas",
        icon: "uil-usd-square",
        link: "/"
    },

];

