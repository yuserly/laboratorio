<?php

namespace App\Http\Controllers;

use App\Models\Qr;
use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class QrController extends Controller
{
    public function generar(Request $request){


        $cantidadqr = $request->cantidad['cantidad'];

        $url_qr = [];

        for ($i=0; $i < $cantidadqr; $i++) {

            $code=uniqid();

            $ruta = 'storage/qr/'.$code.'.png';

            $saveqr = Qr::create([
                'code' => $code ,
                'url_img' => $ruta]);

            QrCode::size(100)->format('png')->generate($code, $ruta);

            array_push($url_qr, $ruta);

        }

        if( count($url_qr) > 0){

            return 1;
        }else{

            return 0;
        }





    }
}
