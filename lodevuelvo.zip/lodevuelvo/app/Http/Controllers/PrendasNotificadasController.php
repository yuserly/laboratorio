<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PrendasNotificadasController extends Controller
{
    //
}
