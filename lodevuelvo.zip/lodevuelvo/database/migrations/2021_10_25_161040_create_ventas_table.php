<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVentasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ventas', function (Blueprint $table) {
            $table->id('id_venta');
            $table->integer('monto');
            $table->integer('iva');
            $table->integer('total');
            $table->date('fecha');
            $table->time('hora');
            $table->unsignedBigInteger('plan_id');
            $table->foreign('plan_id')->references('id_plan')->on('planes');
            $table->unsignedBigInteger('apoderado_id');
            $table->foreign('apoderado_id')->references('id_apoderado')->on('apoderados');
            $table->unsignedBigInteger('estado_id')->default(8);
            $table->foreign('estado_id')->references('id_estado')->on('estados');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ventas');
    }
}
