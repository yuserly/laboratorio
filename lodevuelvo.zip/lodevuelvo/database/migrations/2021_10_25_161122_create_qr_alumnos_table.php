<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateQrAlumnosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('qr_alumnos', function (Blueprint $table) {
            $table->id('id_qr_alumno');
            $table->unsignedBigInteger('qr_id');
            $table->foreign('qr_id')->references('id_qr')->on('qrs');
            $table->unsignedBigInteger('detalle_ventas_id');
            $table->foreign('detalle_ventas_id')->references('id_detalle_ventas')->on('detalles_ventas');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('qr_alumnos');
    }
}
