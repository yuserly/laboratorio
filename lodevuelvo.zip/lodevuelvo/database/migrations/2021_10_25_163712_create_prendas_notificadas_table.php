<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePrendasNotificadasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('prendas_notificadas', function (Blueprint $table) {
            $table->id('id_prenda_notificada');
            $table->string('nombre');
            $table->string('apellido');
            $table->string('email');
            $table->unsignedBigInteger('qr_id');
            $table->foreign('qr_id')->references('id_qr')->on('qrs');
            $table->unsignedBigInteger('estado_id')->default(11);
            $table->foreign('estado_id')->references('id_estado')->on('estados');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('prendas_notificadas');
    }
}
